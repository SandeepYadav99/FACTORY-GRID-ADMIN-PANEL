/**
 * Created by charnjeetelectrovese@gmail.com on 10/30/2019.
 */


/* Desktop Views */
const headerRoutes = [
  {
    path: '/',
    navbarName: 'Material Dashboard',
    component: IndexView,
  },
  // {
  //   path: RouteNames.home,
  //   navbarName: 'Material Dashboard',
  //   component: HomeView,
  //     desktopComponent: HomeDesktop
  // },

  // {
  //   path: '/dashboard',
  //   sidebarName: 'User Profile',
  //   navbarName: 'Profile',
  //   icon: Person,
  //   component: DashboardPage2,
  // },
  // { redirect: true, path: "/", to: "/dashboard", navbarName: "Redirect" }
];

export default headerRoutes;
