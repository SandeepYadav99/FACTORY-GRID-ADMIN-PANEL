import DataTables from './DataTables';

export default DataTables;
