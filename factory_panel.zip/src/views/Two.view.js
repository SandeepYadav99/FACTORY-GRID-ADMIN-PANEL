/**
 * Created by charnjeetelectrovese@gmail.com on 12/4/2018.
 */
import React, { Component } from 'react';

export default class One extends Component {
    render() {
        return(
            <div>
                Two
            </div>
        )
    }
}